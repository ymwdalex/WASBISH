#ifndef __COLLISION_H__
#define __COLLISION_H__

DWORD WINAPI obstacleDetect( LPVOID lpParam );
extern bool threadEndFlag;

#endif

