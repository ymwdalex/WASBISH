#ifndef __MONITOR_H__
#define __MONITOR_H__

#include <windows.h>

extern DWORD WINAPI monitor( LPVOID lpParam );

#endif